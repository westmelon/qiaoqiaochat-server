package com.neo.qiaoqiaochat.dao;

import com.neo.qiaoqiaochat.model.domain.MiUserModel;
import com.neo.qiaoqiaochat.util.SimpleMapper;

public interface MiUserModelMapper extends SimpleMapper<MiUserModel> {
}