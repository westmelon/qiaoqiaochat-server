package com.neo.qiaoqiaochat.dao;

import com.neo.qiaoqiaochat.model.domain.MiFriendModel;
import com.neo.qiaoqiaochat.util.SimpleMapper;

public interface MiFriendModelMapper extends SimpleMapper<MiFriendModel> {
}