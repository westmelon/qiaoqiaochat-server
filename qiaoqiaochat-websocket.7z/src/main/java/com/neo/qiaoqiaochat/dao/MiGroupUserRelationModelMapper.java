package com.neo.qiaoqiaochat.dao;

import com.neo.qiaoqiaochat.model.domain.MiGroupUserRelationModel;
import com.neo.qiaoqiaochat.util.SimpleMapper;

public interface MiGroupUserRelationModelMapper extends SimpleMapper<MiGroupUserRelationModel> {
}