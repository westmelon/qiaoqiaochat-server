package com.neo.qiaoqiaochat.dao;

import com.neo.qiaoqiaochat.model.domain.MiMessageHistoryModel;
import com.neo.qiaoqiaochat.util.SimpleMapper;

public interface MiMessageHistoryModelMapper extends SimpleMapper<MiMessageHistoryModel> {
}