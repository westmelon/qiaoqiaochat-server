package com.neo.qiaoqiaochat.dao;

import com.neo.qiaoqiaochat.model.domain.MiGroupModel;
import com.neo.qiaoqiaochat.util.SimpleMapper;

public interface MiGroupModelMapper extends SimpleMapper<MiGroupModel> {
}