package com.neo.qiaoqiaochat.dao;

import com.neo.qiaoqiaochat.model.domain.MiMessageOfflineModel;
import com.neo.qiaoqiaochat.util.SimpleMapper;

public interface MiMessageOfflineModelMapper extends SimpleMapper<MiMessageOfflineModel> {
}