package com.neo.qiaoqiaochat.dao;

import com.neo.qiaoqiaochat.model.domain.MiMessageContentModel;
import com.neo.qiaoqiaochat.util.SimpleMapper;

public interface MiMessageContentModelMapper extends SimpleMapper<MiMessageContentModel> {
}