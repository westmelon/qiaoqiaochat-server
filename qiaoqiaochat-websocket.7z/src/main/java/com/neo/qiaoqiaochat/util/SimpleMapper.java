package com.neo.qiaoqiaochat.util;

import tk.mybatis.mapper.common.Mapper;

/**
 * Created by Neo Lin on 2017/8/17.
 */
public interface SimpleMapper<T> extends Mapper<T> {
}
